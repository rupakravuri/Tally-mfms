import React from 'react'; 
import TallyFieldExtractor from './TallyFieldExtractor';

function App() {
  return <TallyFieldExtractor defaultServerUrl="34.133.208.212:9000" />;
}

export default App;